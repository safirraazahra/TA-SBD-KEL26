#!/bin/bash

MYSQL_DATA="/home/runner/mysql-data"
MYSQL_RUN="/home/runner/mysql-run"
MYSQL_SOCK="$MYSQL_RUN/mysql.sock"
APP_DIR="/home/runner/workspace/artifacts/printhub"
PORT="${PORT:-8000}"

mkdir -p "$MYSQL_RUN"

# Start MySQL if not running
if ! mysql --socket="$MYSQL_SOCK" -u root -e "SELECT 1;" 2>/dev/null; then
    pkill -f mysqld 2>/dev/null || true
    sleep 1
    mysqld \
      --datadir="$MYSQL_DATA" \
      --socket="$MYSQL_SOCK" \
      --port=3306 \
      --skip-grant-tables \
      --mysqlx=OFF \
      --pid-file="$MYSQL_RUN/mysql.pid" \
      --log-error="$MYSQL_DATA/mysql-error.log" \
      --daemonize

    echo "Waiting for MySQL..."
    for i in $(seq 1 30); do
        mysql --socket="$MYSQL_SOCK" -u root -e "SELECT 1;" 2>/dev/null && break
        sleep 1
    done
fi

echo "MySQL ready!"

mysql --socket="$MYSQL_SOCK" -u root \
    -e "CREATE DATABASE IF NOT EXISTS printhub CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;" 2>/dev/null || true

cd "$APP_DIR"

# Migrations (fast if already run)
php artisan migrate --force 2>&1 | tail -5

# Seed demo data
php artisan db:seed --force 2>&1 | tail -5

# Storage symlink
php artisan storage:link 2>/dev/null || true

# Clear caches
php artisan config:clear 2>/dev/null
php artisan cache:clear 2>/dev/null

echo "Starting PrintHub on port $PORT..."
exec php artisan serve --host=0.0.0.0 --port="$PORT"
